import"./VGrid-CEaDP-cd.js";import{ba as a}from"./main-Bdf_C7XW.js";const p=a("v-spacer","div","VSpacer");export{p as V};
