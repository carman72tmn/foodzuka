/* empty css              */import{b0 as r}from"./main-EaDzB7qF.js";const p=r("v-spacer","div","VSpacer");export{p as V};
