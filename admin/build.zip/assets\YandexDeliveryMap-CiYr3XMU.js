import{_ as b,h,i as x,Y as w,o as m,c as v,a as $,b as k,w as C,v as j,Z as O,d as M}from"./main-EaDzB7qF.js";import{V as P}from"./VAlert-9zWX1UFm.js";const B={class:"yandex-map-wrapper"},z={key:0,class:"no-api-key"},E={__name:"YandexDeliveryMap",props:{zones:{type:Array,required:!0},customPolygons:{type:Array,default:()=>[]},apiKey:{type:String,required:!0}},emits:["polygonClick"],setup(d,{expose:g,emit:u}){const n=d,y=u,c=M(null);let s=null,a=[],i=new Map;const l=()=>{!window.ymaps||s||window.ymaps.ready(()=>{s=new window.ymaps.Map(c.value,{center:[57.1522,65.5272],zoom:11,controls:["zoomControl","typeSelector","fullscreenControl"]}),p()})},p=()=>{s&&(a.forEach(e=>s.geoObjects.remove(e)),a=[],i.clear(),n.zones.forEach(e=>{if(e.polygon_coordinates)try{const o=JSON.parse(e.polygon_coordinates);if(!o||!o.length)return;const t="#0066ff",r=new window.ymaps.Polygon([o],{hintContent:`<strong>${e.name}</strong><br/>${e.delivery_cost} ₽`,balloonContent:`
            <div class="map-balloon">
              <div class="map-balloon-header" style="background-color: ${t}">
                ${e.name} (iiko)
              </div>
              <div class="map-balloon-content">
                <div class="d-flex justify-space-between mb-1">
                  <span>Мин. заказ:</span>
                  <strong>${e.min_order_amount||0} ₽</strong>
                </div>
                <div class="d-flex justify-space-between mb-1">
                  <span>Доставка:</span>
                  <strong class="${e.delivery_cost===0?"text-success":""}">
                    ${e.delivery_cost===0?"Бесплатно":e.delivery_cost+" ₽"}
                  </strong>
                </div>
              </div>
            </div>
          `},{fillColor:t+"22",strokeColor:t,strokeOpacity:.8,strokeWidth:2,zIndex:0});s.geoObjects.add(r),a.push(r),i.set(`iiko-${e.id}`,r)}catch(o){console.error("Error parsing zone coordinates:",o)}}),n.customPolygons.forEach(e=>{var r;if(!e.coordinates||!e.coordinates.length)return;const o=e.fill_color||(e.delivery_zone_id?"#4caf50":"#ff9800"),t=new window.ymaps.Polygon([e.coordinates],{hintContent:`<strong>${e.name}</strong><br/>${e.delivery_cost} ₽`,balloonContent:`
          <div class="map-balloon">
            <div class="map-balloon-header" style="background-color: ${o}">
              ${e.name}
            </div>
            <div class="map-balloon-content">
              ${e.description?`<div class="mb-2 text-grey-darken-1">${e.description}</div>`:""}
              
              <div class="d-flex justify-space-between mb-1">
                <span>Время:</span>
                <strong>${e.min_delivery_time||"?"}-${e.max_delivery_time||"?"} мин.</strong>
              </div>
              
              <div class="d-flex justify-space-between mb-1">
                <span>Мин. заказ:</span>
                <strong>${e.min_order_amount||0} ₽</strong>
              </div>
              
              <div class="d-flex justify-space-between mb-1">
                <span>Доставка:</span>
                <strong class="${e.delivery_cost===0?"text-success":""}">
                  ${e.delivery_cost===0?"Бесплатно":e.delivery_cost+" ₽"}
                </strong>
              </div>
              
              ${e.free_delivery_threshold>0?`
              <div class="d-flex justify-space-between mb-1 text-primary">
                <span>Бесплатно от:</span>
                <strong>${e.free_delivery_threshold} ₽</strong>
              </div>
              `:""}

              <div class="d-flex justify-space-between mb-1 text-grey" style="font-size: 0.8em">
                <span>Приоритет:</span>
                <strong>${e.priority||0}</strong>
              </div>
              
              <div class="mt-2 pt-2 border-top">
                <small class="text-grey">
                  <i class="bx bx-link-alt"></i> 
                  ${e.delivery_zone_id?`Зона: ${((r=n.zones.find(_=>_.id===e.delivery_zone_id))==null?void 0:r.name)||"Неизвестно"}`:"Не привязан к iiko"}
                </small>
              </div>
            </div>
          </div>
        `},{fillColor:o+"44",strokeColor:o,strokeOpacity:.9,strokeWidth:2,zIndex:e.priority||1,hoverFillColor:o+"66",hoverStrokeWidth:4});t.events.add("click",()=>{y("polygonClick",e)}),s.geoObjects.add(t),a.push(t),i.set(`custom-${e.id}`,t)}),a.length&&s.setBounds(s.geoObjects.getBounds(),{checkZoomRange:!0,zoomMargin:20}))};g({focusOnPolygon:(e,o)=>{const t=i.get(`${e}-${o}`);t&&s&&(s.setBounds(t.geometry.getBounds(),{checkZoomRange:!0,zoomMargin:50}),t.balloon.open())}});const f=()=>{if(window.ymaps){l();return}const e=document.createElement("script");e.src=`https://api-maps.yandex.ru/2.1/?apikey=${n.apiKey}&lang=ru_RU`,e.async=!0,e.onload=l,document.head.appendChild(e)};return h([()=>n.zones,()=>n.customPolygons],()=>{p()},{deep:!0}),x(()=>{n.apiKey&&f()}),w(()=>{s&&(s.destroy(),s=null)}),(e,o)=>(m(),v("div",B,[$("div",{ref_key:"mapContainer",ref:c,class:"map-container"},null,512),d.apiKey?O("",!0):(m(),v("div",z,[k(P,{type:"warning",variant:"tonal"},{default:C(()=>[...o[0]||(o[0]=[j(" API ключ Яндекс.Карт не настроен. Пожалуйста, укажите его в настройках. ",-1)])]),_:1})]))]))}},S=b(E,[["__scopeId","data-v-9cb4c2b0"]]);export{S as Y};
