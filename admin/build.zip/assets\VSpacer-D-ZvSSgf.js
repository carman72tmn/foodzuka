/* empty css              */import{g as r}from"./VCard-DX0cvvmy.js";const p=r("v-spacer","div","VSpacer");export{p as V};
