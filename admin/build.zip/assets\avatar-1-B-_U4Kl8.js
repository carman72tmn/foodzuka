const a="/admin/build/assets/avatar-1-DL1ARROH.png";export{a};
