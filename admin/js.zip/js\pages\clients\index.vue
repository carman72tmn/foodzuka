/* eslint-disable camelcase */
<script setup>
import { ref, onMounted } from 'vue'
import { formatDateTime, formatDate } from '@/utils/date'

const clients = ref([])
const loading = ref(true)

const headers = [
  { title: 'ID / Имя', key: 'id_name' },
  { title: 'Телефон', key: 'phone' },
  { title: 'Email', key: 'email' },
  { title: 'День рождения', key: 'birthday' },
  { title: 'Статус лояльности', key: 'loyalty_status_id' },
  { title: 'Бонусы (₽)', key: 'bonus_points', align: 'end' },
  { title: 'Заказы', key: 'total_orders_count', align: 'end' },
  { title: 'Сумма заказов', key: 'total_orders_amount', align: 'end' },
  { title: 'Дата посещения', key: 'last_order_date' },
  { title: 'Блок', key: 'is_blocked', align: 'center' },
  { title: 'Действия', key: 'actions', sortable: false, align: 'end' },
]

const snackbar = ref({
  show: false,
  text: '',
  color: 'success',
})

const getLoyaltyColor = statusId => {
  if (statusId === 1) return 'success'
  if (statusId === 2) return 'warning'

  return 'grey'
}

const getLoyaltyStatusName = statusId => {
  if (statusId === 1) return 'Активен'
  if (statusId === 2) return 'Новый'

  return 'Неизвестно'
}

const fetchClients = async () => {
  loading.value = true
  try {
    const response = await fetch('/api/v1/customers')
    const data = await response.json()

    clients.value = data.map(c => ({ ...c, syncing: false }))
  } catch (error) {
    snackbar.value = {
      show: true,
      text: 'Ошибка при загрузке клиентов',
      color: 'error',
    }
  } finally {
    loading.value = false
  }
}

const toggleBlock = async item => {
  try {
    await fetch(`/api/v1/customers/${item.id}/block`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ is_blocked: item.is_blocked }),
    })

    snackbar.value = {
      show: true,
      text: item.is_blocked ? 'Клиент заблокирован' : 'Клиент разблокирован',
      color: item.is_blocked ? 'error' : 'success',
    }
  } catch (error) {
    item.is_blocked = !item.is_blocked
    snackbar.value = {
      show: true,
      text: 'Ошибка при изменении статуса',
      color: 'error',
    }
  }
}

const syncWithIiko = async item => {
  item.syncing = true
  try {
    const response = await fetch(`/api/v1/customers/${item.id}/sync`, { method: 'POST' })
    if (response.ok) {
      const updatedCustomer = await response.json()

      // Update local item
      Object.assign(item, updatedCustomer)

      snackbar.value = {
        show: true,
        text: `Данные клиента ${item.name} синхронизированы`,
        color: 'success',
      }
    } else {
      const error = await response.json()

      snackbar.value = {
        show: true,
        text: `Ошибка: ${error.detail || 'Не удалось синхронизировать'}`,
        color: 'error',
      }
    }
  } catch (error) {
    snackbar.value = {
      show: true,
      text: 'Ошибка сетевого соединения',
      color: 'error',
    }
  } finally {
    item.syncing = false
  }
}

const formatMoney = val => {
  if (val === undefined || val === null) return '0'

  return new Intl.NumberFormat('ru-RU').format(val)
}

onMounted(() => {
  fetchClients()
})
</script>

<template>
  <div>
    <div class="d-flex align-center justify-space-between mb-4">
      <h2 class="text-h4 mb-0">
        Все клиенты
      </h2>
      <div>
        <VBtn
          color="primary"
          variant="tonal"
          prepend-icon="ri-download-line"
          class="me-2"
        >
          Экспорт
        </VBtn>
        <VBtn
          color="primary"
          prepend-icon="ri-add-line"
        >
          Добавить клиента
        </VBtn>
      </div>
    </div>

    <VCard>
      <VCardText class="d-flex align-center flex-wrap gap-4">
        <div style="width: 250px;">
          <VTextField
            placeholder="Поиск по телефону или имени"
            prepend-inner-icon="ri-search-line"
            density="compact"
            hide-details
          />
        </div>
      </VCardText>
      <VDivider />

      <VDataTable
        :headers="headers"
        :items="clients"
        :loading="loading"
        hover
      >
        <template #item.id_name="{ item }">
          <div class="d-flex flex-column align-start">
            <span class="font-weight-medium">{{ item.name || 'Без имени' }}</span>
            <span class="text-caption text-disabled">ID: {{ item.id }}</span>
          </div>
        </template>

        <template #item.phone="{ item }">
          <span class="text-body-2 text-primary font-weight-medium">+{{ item.phone }}</span>
        </template>

        <template #item.email="{ item }">
          <span class="text-body-2">{{ item.email || '-' }}</span>
        </template>

        <template #item.birthday="{ item }">
          <span class="text-body-2">{{ item.birthday ? formatDate(item.birthday) : '-' }}</span>
        </template>

        <template #item.loyalty_status_id="{ item }">
          <VChip
            size="small"
            :color="getLoyaltyColor(item.loyalty_status_id)"
          >
            {{ getLoyaltyStatusName(item.loyalty_status_id) }}
          </VChip>
        </template>

        <template #item.bonus_points="{ item }">
          <span class="text-success font-weight-bold">{{ formatMoney(item.bonus_points) }}</span>
        </template>

        <template #item.total_orders_amount="{ item }">
          <span>{{ formatMoney(item.total_orders_amount) }}</span>
        </template>

        <template #item.last_order_date="{ item }">
          <span class="text-body-2">{{ item.last_order_date ? formatDate(item.last_order_date) : '-' }}</span>
        </template>

        <template #item.is_blocked="{ item }">
          <VSwitch
            v-model="item.is_blocked"
            color="error"
            density="compact"
            hide-details
            @change="toggleBlock(item)"
          />
        </template>

        <template #item.actions="{ item }">
          <VBtn
            icon="ri-refresh-line"
            size="small"
            variant="text"
            color="success"
            class="me-1"
            title="Синхронизировать с iiko"
            :loading="item.syncing"
            @click="syncWithIiko(item)"
          />
          <VBtn
            icon="ri-eye-line"
            size="small"
            variant="text"
            color="primary"
            class="me-1"
            title="Открыть профиль"
          />
        </template>
      </VDataTable>
    </VCard>

    <VSnackbar
      v-model="snackbar.show"
      :color="snackbar.color"
      timeout="3000"
    >
      {{ snackbar.text }}
    </VSnackbar>
  </div>
</template>
