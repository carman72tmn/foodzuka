"""
Сервис-оркестратор для синхронизации данных с iiko Cloud
"""
import logging
import asyncio
import json
from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta, timezone
import zoneinfo
from decimal import Decimal
from sqlmodel import Session, select
from sqlalchemy import func
from sqlalchemy.orm.attributes import flag_modified

from app.models.category import Category
from app.models.product import Product, ProductSize, ProductModifierGroup, ProductModifier
from app.models.sync_log import SyncLog
from app.models.order import Order, OrderItem, OrderStatus
from app.models.employee import Employee, Shift, Schedule, CourierOrder
from app.models.company import Branch, Company, DeliveryZone
from app.models.customer import Customer
from app.models.iiko_settings import IikoSettings
from app.models.olap_revenue import OlapRevenueRecord
from app.core.config import settings
from app.services.iiko_service import iiko_service
from app.core.logging_utils import log_audit

logger = logging.getLogger(__name__)

class IikoSyncService:
    def __init__(self):
        self._terminal_groups_cache = {}

    def _get_tz(self, session: Session):
        """Получение часового пояса из настроек"""
        from app.core.datetime_utils import get_tz
        return get_tz(session)

    async def sync_menu(self, session: Session) -> Dict[str, Any]:
        """Синхронизация каталога меню (категории + товары)"""
        log = SyncLog(sync_type="menu", status="running")
        session.add(log)
        session.commit()
        
        settings_db = session.exec(select(IikoSettings)).first()
        api_login = settings_db.api_login if settings_db else None
        org_id = settings_db.organization_id if settings_db else None
        ext_menu_id = settings_db.external_menu_id if settings_db else None
        
        try:
            if ext_menu_id:
                logger.info(f"Syncing from External Menu ID: {ext_menu_id}")
                menu_data = await iiko_service.get_external_menu_by_id(ext_menu_id, api_login=api_login, organization_id=org_id)
                res = await self._sync_from_external_menu(session, menu_data, log)
            else:
                logger.info("Syncing from Nomenclature (Classic API)")
                nomenclature = await iiko_service.get_nomenclature(api_login=api_login, organization_id=org_id)
                res = await self._sync_from_nomenclature(session, nomenclature, log)
            
            # Гарантируем наличие success и полей для схемы
            response = {
                "success": True,
                "categories_synced": res.get("categories", 0),
                "products_synced": res.get("products", 0),
                "message": f"Синхронизация завершена успешно: {res.get('categories', 0)} категорий, {res.get('products', 0)} товаров"
            }
            
            log.status = "success"
            log.details = response["message"]
            session.add(log)
            session.commit()
            
            # Добавляем запись в аудит
            log_audit(action="manual_sync", resource_type="menu", message=response["message"])
            
            return response
        except Exception as e:
            logger.error(f"Menu sync failed: {e}", exc_info=True)
            log.status = "error"
            log.details = str(e)
            session.add(log)
            session.commit()
            
            # Добавляем запись в аудит об ошибке
            log_audit(action="manual_sync_failed", resource_type="menu", message=str(e))
            
            return {
                "success": False,
                "error": str(e),
                "message": f"Ошибка синхронизации: {str(e)}"
            }

    async def sync_categories_only(self, session: Session) -> Dict[str, Any]:
        """Синхронизация только категорий из iiko (вызывает полную синхронизацию меню)"""
        res = await self.sync_menu(session)
        return {
            "success": res.get("success", False),
            "categories_synced": res.get("categories_synced", 0),
            "message": f"Синхронизировано категорий: {res.get('categories_synced', 0)}"
        }

    async def _sync_from_external_menu(self, session: Session, menu_data: Dict[str, Any], log: SyncLog) -> Dict[str, Any]:
        """Логика обработки внешнего меню iiko (API v2 /menu/by_id)"""
        if not menu_data:
            return {"categories": 0, "products": 0}
        
        categories_synced = 0
        products_synced = 0

        # 1. Синхронизация категорий
        cats_list = menu_data.get("itemCategories") or menu_data.get("groups") or []
        for cat_data in cats_list:
            cat_id = cat_data.get("id")
            if not cat_id: continue
            
            cat = session.exec(select(Category).where(Category.iiko_id == cat_id)).first()
            if cat:
                cat.name = cat_data["name"]
                cat.updated_at = datetime.now(timezone.utc)
            else:
                cat = Category(
                    iiko_id=cat_id,
                    name=cat_data["name"],
                    is_active=True
                )
                session.add(cat)
            categories_synced += 1
        session.commit()

        # 2. Синхронизация товаров
        # В v2 товары сгруппированы по категориям в itemCategories
        for cat_data in cats_list:
            iiko_cat_id = cat_data.get("id")
            local_cat = session.exec(select(Category).where(Category.iiko_id == iiko_cat_id)).first()
            category_id = local_cat.id if local_cat else None
            
            items_list = cat_data.get("items") or cat_data.get("products") or []
            for item_data in items_list:
                item_id = item_data.get("itemId") or item_data.get("id")
                if not item_id: continue
                
                prod = session.exec(select(Product).where(Product.iiko_id == item_id)).first()
                
                # Извлекаем данные из первого размера для базовых полей товара
                sizes = item_data.get("itemSizes", [])
                price = 0
                nutritions = {}
                weight = None
                
                if sizes:
                    s0 = sizes[0]
                    prices = s0.get("prices", [])
                    if prices: price = prices[0].get("price", 0)
                    nutritions = s0.get("nutritionPerHundredGrams") or s0.get("nutritions") or {}
                    weight = s0.get("portionWeightGrams")
                elif "price" in item_data: 
                    price = item_data["price"]

                updated_data = {
                    "name": item_data["name"],
                    "description": item_data.get("description") or "",
                    "price": float(price or 0),
                    "article": item_data.get("sku") or "", 
                    "category_id": category_id,
                    "is_available": not item_data.get("isHidden", False),
                    "weight_grams": int(weight) if weight else None,
                    "calories": int(nutritions.get("energy") or 0) or None,
                    "proteins": float(nutritions.get("proteins") or 0) or None,
                    "fats": float(nutritions.get("fats") or 0) or None,
                    "carbohydrates": float(nutritions.get("carbs") or 0) or None,
                    "updated_at": datetime.now(timezone.utc)
                }

                if prod:
                    for key, val in updated_data.items(): setattr(prod, key, val)
                else:
                    prod = Product(iiko_id=item_id, **updated_data)
                    session.add(prod)
                
                session.flush() # Получаем ID

                # --- Синхронизация размеров ---
                for existing_size in session.exec(select(ProductSize).where(ProductSize.product_id == prod.id)).all():
                    session.delete(existing_size)
                
                if sizes:
                    for s_data in sizes:
                        s_price = 0
                        if s_data.get("prices"): s_price = s_data["prices"][0].get("price", 0)
                        
                        session.add(ProductSize(
                            product_id=prod.id,
                            iiko_id=s_data.get("sizeId") or item_id,
                            name=s_data.get("sizeName") or "Стандарт",
                            price=float(s_price or 0),
                            is_default=s_data.get("isDefault", False)
                        ))
                else:
                    session.add(ProductSize(
                        product_id=prod.id,
                        iiko_id=item_id,
                        name="Стандарт",
                        price=float(price or 0),
                        is_default=True
                    ))

                # --- Синхронизация модификаторов ---
                # Берем модификаторы из дефолтного размера (или первого доступного)
                target_size = next((s for s in sizes if s.get("isDefault")), sizes[0] if sizes else None)
                if target_size:
                    # Очищаем старые группы модификаторов
                    for existing_group in session.exec(select(ProductModifierGroup).where(ProductModifierGroup.product_id == prod.id)).all():
                        session.delete(existing_group)
                    
                    mod_groups = target_size.get("itemModifierGroups", [])
                    for mg_data in mod_groups:
                        mg_id = mg_data.get("itemGroupId") or mg_data.get("modifierGroupId") or f"mg_{mg_data['name']}"
                        
                        new_group = ProductModifierGroup(
                            product_id=prod.id,
                            iiko_id=mg_id,
                            name=mg_data["name"],
                            min_amount=mg_data.get("minAmount", 0),
                            max_amount=mg_data.get("maxAmount", 1),
                            is_required=mg_data.get("minAmount", 0) > 0
                        )
                        session.add(new_group)
                        session.flush()
                        
                        for m_item in mg_data.get("items", []):
                            m_price = 0
                            if m_item.get("prices"): m_price = m_item["prices"][0].get("price", 0)
                            
                            session.add(ProductModifier(
                                group_id=new_group.id,
                                iiko_id=m_item["itemId"],
                                name=m_item["name"],
                                price=float(m_price),
                                min_amount=m_item.get("minAmount", 0),
                                max_amount=m_item.get("maxAmount", 1),
                                default_amount=m_item.get("defaultAmount", 0)
                            ))

                products_synced += 1
        
        session.commit()
        return {"categories": categories_synced, "products": products_synced}

    async def _sync_from_nomenclature(self, session: Session, nomenclature: Dict[str, Any], log: SyncLog) -> Dict[str, Any]:
        """Обработка классической номенклатуры iiko (groups + products + sizes)"""
        if not nomenclature:
            return {"categories": 0, "products": 0}

        categories_synced = 0
        products_synced = 0

        # 1. Синхронизация категорий (groups)
        if "groups" in nomenclature:
            for g in nomenclature["groups"]:
                if g.get("isDeleted"): continue
                
                cat = session.exec(select(Category).where(Category.iiko_id == g["id"])).first()
                if cat:
                    cat.name = g["name"]
                    cat.updated_at = datetime.now(timezone.utc)
                else:
                    cat = Category(
                        iiko_id=g["id"],
                        name=g["name"],
                        is_active=True
                    )
                    session.add(cat)
                categories_synced += 1
            session.commit()

        # 2. Маппинг размеров для товаров
        size_map = {s["id"]: s["name"] for s in nomenclature.get("sizes", [])}

        # 3. Синхронизация товаров (products)
        if "products" in nomenclature:
            for p in nomenclature["products"]:
                if p.get("type") == "Service": continue # Пропускаем услуги
                
                prod = session.exec(select(Product).where(Product.iiko_id == p["id"])).first()
                
                # Поиск локальной категории
                category_id = None
                if p.get("parentGroup"):
                    local_cat = session.exec(select(Category).where(Category.iiko_id == p["parentGroup"])).first()
                    if local_cat: category_id = local_cat.id
                
                # Определение базовой цены (первый доступный размер)
                price = 0
                if p.get("sizePrices"):
                    price = p["sizePrices"][0].get("price", {}).get("currentPrice", 0)

                updated_data = {
                    "name": p["name"],
                    "description": p.get("description") or "",
                    "price": float(price),
                    "article": p.get("code") or "",
                    "category_id": category_id,
                    "is_available": not p.get("isDeleted", False),
                    "updated_at": datetime.now(timezone.utc)
                }

                if prod:
                    for key, val in updated_data.items(): setattr(prod, key, val)
                else:
                    prod = Product(iiko_id=p["id"], **updated_data)
                    session.add(prod)
                
                session.flush() # Получаем ID товара
                
                # --- Синхронизация размеров ---
                for existing_size in session.exec(select(ProductSize).where(ProductSize.product_id == prod.id)).all():
                    session.delete(existing_size)
                
                if p.get("sizePrices"):
                    for sp in p["sizePrices"]:
                        s_id = sp.get("sizeId")
                        s_name = size_map.get(s_id, "Стандарт")
                        session.add(ProductSize(
                            product_id=prod.id,
                            iiko_id=s_id or "default",
                            name=s_name,
                            price=float(sp.get("price", {}).get("currentPrice", 0)),
                            is_default=(len(p["sizePrices"]) == 1 or sp.get("isDefault", False))
                        ))

                products_synced += 1
            
            session.commit()

        return {"categories": categories_synced, "products": products_synced}

    async def process_iiko_order(self, session: Session, iiko_order_data: Dict[str, Any], organization_id: str, iiko_card_data: Optional[Dict[str, Any]] = None):
        """Интегрированный метод обработки заказа: консолидированная и очищенная версия"""
        if not iiko_order_data:
            logger.warning("Received empty order data from iiko")
            return
            
        try:
            # 1. Базовые данные заказа
            order_id_iiko = iiko_order_data.get("id")
            o_data = iiko_order_data.get("order")
            if not o_data:
                o_data = iiko_order_data
            if not order_id_iiko:
                order_id_iiko = o_data.get("id")

            if not order_id_iiko:
                logger.warning(f"Order data missing ID: {iiko_order_data}")
                return
            
            settings_db = session.exec(select(IikoSettings)).first()
            def clean_str(val):
                if val is None or str(val).lower() in ("none", "null", ""):
                    return ""
                return str(val).strip()

            # 2. Статус и внешние номера
            raw_status = clean_str(o_data.get("status") or iiko_order_data.get("creationStatus"))
            raw_status_lower = raw_status.lower()
            external_number = clean_str(o_data.get("number") or o_data.get("externalNumber")) or None

            # 3. Таймзона и время
            from app.core.datetime_utils import get_tz_name
            tz_name = get_tz_name(session)
            try:
                import zoneinfo
                tz = zoneinfo.ZoneInfo(tz_name)
            except Exception:
                import zoneinfo
                tz = zoneinfo.ZoneInfo("Asia/Yekaterinburg")
            current_time_tz = datetime.now(tz)
            
            # Поиск даты создания в разных местах (iiko API может менять структуру)
            iiko_creation_time_raw = (
                (o_data.get("creationInfo") or {}).get("creationDate") or 
                o_data.get("creationDate") or
                o_data.get("whenCreated")
            )
            iiko_creation_time = None
            if iiko_creation_time_raw:
                try:
                    if 'Z' in iiko_creation_time_raw:
                        iiko_creation_time = datetime.fromisoformat(iiko_creation_time_raw.replace('Z', '+00:00'))
                    else:
                        dt = datetime.fromisoformat(iiko_creation_time_raw)
                        if dt.tzinfo is None:
                            # iiko Cloud API v2 присылает время в UTC, даже если нет суффикса Z
                            dt = dt.replace(tzinfo=timezone.utc)
                        iiko_creation_time = dt.astimezone(timezone.utc)
                except Exception:
                    pass

            # 4. Клиент
            c_data = o_data.get("customer") or {}
            c_first = clean_str(c_data.get("name"))
            c_last = clean_str(c_data.get("surname"))
            full_customer_name = f"{c_first} {c_last}".strip() or "Гость"
            phone = clean_str(o_data.get("phone") or c_data.get("phone"))

            # 5. Адрес
            street_name = None
            house, flat, entrance, floor, doorphone = "", "", "", "", ""
            
            def parse_addr(addr_obj, c_name=None, fmt="components"):
                nonlocal street_name, house, flat, entrance, floor, doorphone
                if not addr_obj or not isinstance(addr_obj, dict): return None
                
                house = clean_str(addr_obj.get("house"))
                flat = clean_str(addr_obj.get("flat"))
                entrance = clean_str(addr_obj.get("entrance"))
                floor = clean_str(addr_obj.get("floor"))
                doorphone = clean_str(addr_obj.get("doorphone"))
                s_obj = addr_obj.get("street")
                street_name = s_obj.get("name") if isinstance(s_obj, dict) else (clean_str(s_obj) or None)
                
                # Если улица - прочерки, сбрасываем её
                if street_name and all(char in "-. " for char in street_name): street_name = None

                # Собираем доп. детали (используем понятные сокращения)
                details = []
                if entrance: details.append(f"под. {entrance}")
                if floor: details.append(f"эт. {floor}")
                if flat: details.append(f"кв. {flat}")
                if doorphone: details.append(f"дом-фон: {doorphone}")
                details_str = ", ".join(details)

                base = None
                # Если выбран формат line1, в приоритете берем готовую строку от iiko
                if fmt == "line1": 
                    base = clean_str(addr_obj.get("line1") or addr_obj.get("addressString"))
                
                # Если base пустой или формат "components", собираем вручную
                if not base:
                    p = []
                    if c_name: p.append(c_name)
                    if street_name: p.append(f"ул. {street_name}")
                    if house and house != "0": p.append(f"д. {house}")
                    base = ", ".join(p)
                
                if not base: return details_str or c_name or "Самовывоз"
                
                # Добавляем детали к адресу, если их там еще нет (проверка по вхождению)
                final = base
                if details_str:
                    for d in details:
                        # Проверяем наличие ключевой части (например "кв. 5") в строке
                        if d not in final:
                            final += f", {d}"
                
                return final

            raw_addr = o_data.get("address") or {}
            city = settings_db.city_name if settings_db else "Тюмень"
            c_raw = raw_addr.get("city") if isinstance(raw_addr, dict) else None
            if isinstance(c_raw, dict): city = c_raw.get("name") or city
            elif isinstance(c_raw, str): city = c_raw

            addr_fmt = (settings_db.address_format or "components") if settings_db else "components"
            delivery_address = parse_addr(raw_addr, c_name=city, fmt=addr_fmt)
            if not delivery_address or "Самовывоз" in str(delivery_address):
                dp = o_data.get("deliveryPoint") or {}
                delivery_address = parse_addr(dp.get("address"), c_name=city, fmt=addr_fmt) or "Самовывоз"

            # --- НОВАЯ ЛОГИКА ОПЛАТЫ ---
            sum_total = Decimal(str(o_data.get("sum") or 0)) # Базовая сумма (до скидок)
            # Сумма к оплате после применения скидок
            total_with_discount = Decimal(str(o_data.get("totalSum") or o_data.get("total") or sum_total))
            
            # Скидки
            disc_list = o_data.get("discounts") or o_data.get("concessions") or []
            total_discount = sum([Decimal(str((d or {}).get("sum") or 0)) for d in disc_list if isinstance(d, dict)])

            payments = o_data.get("payments") or []
            total_paid = 0
            pm_list_detailed = []
            pm_list = []
            
            for p in payments:
                if not isinstance(p, dict): continue
                pt = p.get("paymentType") or {}
                pn = pt.get("name") if isinstance(pt, dict) else clean_str(pt)
                pk = clean_str(p.get("paymentTypeKind") or p.get("kind") or "").lower()
                if not pn: pn = pk or "Тип оплаты"
                
                psum = float(p.get("sum") or 0)
                
                is_processed_externally = p.get("isProcessedExternally", False) or p.get("processedExternally", False)
                is_prepay = p.get("isPrepay", False) or p.get("prepay", False)
                status_payment = p.get("status", "").lower()
                
                # Считаем платеж проведенным
                is_processed = bool(is_processed_externally or is_prepay or status_payment in ["processed", "closed", "success"] or pk in ["card", "online", "external"])
                
                if is_processed:
                    total_paid += psum
                
                pm_list_detailed.append({
                    "name": pn,
                    "kind": pk,
                    "sum": psum,
                    "is_processed": is_processed
                })
                if pn: pm_list.append(pn)
            
            # Учитываем iiko Cloud processedPaymentsSum (если он больше того что мы спарсили)
            processed_params = float(o_data.get("processedPaymentsSum") or 0)
            if processed_params > total_paid:
                total_paid = processed_params

            # Считаем остаток
            left_to_pay = max(Decimal('0.00'), total_with_discount - Decimal(str(total_paid)))
            is_paid = (left_to_pay <= 0)
            
            payment_method = ", ".join(list(set(pm_list))) or "Не указан"
            
            # Фолбэк статуса закрытого заказа
            if not is_paid and raw_status_lower in ("closed", "delivered"):
                is_paid = True
                left_to_pay = Decimal('0.00')

            status_map = {
                "unconfirmed": OrderStatus.unconfirmed, 
                "waitapproval": OrderStatus.unconfirmed, 
                "waitingforselection": OrderStatus.unconfirmed,
                "awaitingconfirmation": OrderStatus.unconfirmed,
                "accepted": OrderStatus.confirmed,
                "waitcooking": OrderStatus.confirmed,
                "readyforcooking": OrderStatus.confirmed,
                "cooking": OrderStatus.cooking, 
                "cookingstarted": OrderStatus.cooking,
                "cookingfinished": OrderStatus.ready, 
                "cookingcompleted": OrderStatus.ready,
                "waiting": OrderStatus.ready, 
                "ready": OrderStatus.ready,
                "readyforpickup": OrderStatus.ready_for_pickup,
                "onway": OrderStatus.delivering, 
                "delivered": OrderStatus.delivered, 
                "closed": OrderStatus.closed,
                "cancelled": OrderStatus.cancelled
            }
            mapped_status = status_map.get(raw_status_lower, OrderStatus.new)

            # Если заказ закрыт в iiko - он точно оплачен (для нашей CRM)
            if not is_paid and mapped_status in (OrderStatus.closed, OrderStatus.delivered):
                is_paid = True
                left_to_pay = Decimal('0.00')
                logger.info(f"Order {order_id_iiko}: Paid via status enforcement ('{mapped_status}')")

            # 7. Курьер, тип и дополнительные данные
            courier_name = "Не назначен"
            ci = o_data.get("courierInfo") or {}
            if isinstance(ci, dict):
                c_obj = ci.get("courier") or {}
                if isinstance(c_obj, dict):
                    fn = clean_str(c_obj.get("firstName") or c_obj.get("name"))
                    ln = clean_str(c_obj.get("lastName"))
                    courier_name = f"{fn} {ln}".strip() or clean_str(ci.get("courierName")) or "Не назначен"

            stype = clean_str(o_data.get("orderServiceType")).lower()
            if not stype and isinstance(o_data.get("orderType"), dict):
                stype = clean_str((o_data.get("orderType") or {}).get("orderServiceType")).lower()
            
            order_type = "Доставка"
            if any(x in stype for x in ["pickup", "client", "само"]): 
                order_type = "Самовывоз"
            elif any(x in stype for x in ["common", "table", "зал", "рест"]): 
                order_type = "В ресторане"

            # Новые поля для полной информативности
            source = clean_str(o_data.get("source")) or "iiko"
            def parse_dt(dt_str):
                if not dt_str:
                    return None
                try:
                    if 'Z' in dt_str:
                        return datetime.fromisoformat(dt_str.replace('Z', '+00:00'))
                    dt = datetime.fromisoformat(dt_str)
                    if dt.tzinfo is None:
                        # Считаем за UTC
                        dt = dt.replace(tzinfo=timezone.utc)
                    return dt.astimezone(timezone.utc)
                except:
                    return None

            di = o_data.get("deliveryInfo") or {}
            expected_time = None
            actual_time = None
            if di:
                expected_time = parse_dt(di.get("expectedDate") or di.get("completeBefore"))
                actual_time = parse_dt(di.get("actualDate") or di.get("actualTime"))
            
            is_on_time = di.get("isOnTime", True)
            is_asap = o_data.get("isAsap", True)
            delay = di.get("delayMinutes")
            admin_name = clean_str((o_data.get("conformationInfo") or {}).get("confirmedBy")) # conformation -> confirmation (iiko typo is possible, checking both)
            if not admin_name:
                admin_name = clean_str((o_data.get("confirmationInfo") or {}).get("confirmedBy"))

            # 8. Сохранение
            order = session.exec(select(Order).where(Order.iiko_order_id == order_id_iiko)).first()
            if not order:
                order = Order(iiko_order_id=order_id_iiko, branch_id=1)
                order.iiko_creation_time = iiko_creation_time
                order.status_history = [{"status": mapped_status, "time": current_time_tz.isoformat(), "comment": "Синхронизирован"}]
            else:
                if order.status != mapped_status:
                    h = list(order.status_history or [])
                    h.append({"status": mapped_status, "time": current_time_tz.isoformat(), "comment": f"iiko: {raw_status}"})
                    order.status_history = h
                    flag_modified(order, "status_history")

            order.status = mapped_status
            order.external_number = external_number or order.external_number
            order.customer_name = full_customer_name
            order.customer_phone = phone
            order.courier_name = courier_name
            order.delivery_address = delivery_address
            order.comment = clean_str(o_data.get("comment")) or None
            order.city, order.street, order.house = city, street_name, house
            order.flat, order.entrance, order.floor, order.doorphone = flat, entrance, floor, doorphone
            order.total_amount, order.total_with_discount, order.total_discount = sum_total, total_with_discount, total_discount
            order.is_paid, order.payment_method, order.order_type = is_paid, payment_method, order_type
            
            # Доп. поля
            order.source = source
            order.expected_time = expected_time or order.expected_time
            order.actual_time = actual_time or order.actual_time
            order.is_on_time = is_on_time
            order.is_asap = is_asap
            order.delay_minutes = delay
            order.admin_name = admin_name or order.admin_name

            # --- Определение зоны доставки по адресу ---
            if order_type == "Доставка" and city and street_name and house:
                try:
                    zone_data = await iiko_service.check_address_zone(
                        organization_id=organization_id,
                        city=city,
                        street=street_name,
                        house=house,
                        api_login=settings_db.api_login
                    )
                    if zone_data and zone_data.get("zone"):
                        order.delivery_zone = zone_data.get("zone")
                        logger.info(f"Order {order_id_iiko}: Auto-detected zone: {order.delivery_zone}")
                except Exception as e:
                    logger.warning(f"Could not auto-detect zone: {e}")
            # ---------------------------------------------

            # --- НОВАЯ ЛОГИКА СОСТАВА ЗАКАЗА (с именами и защитой от затирания) ---
            from app.models.product import Product 
            
            if "items" in o_data and isinstance(o_data["items"], list) and len(o_data["items"]) > 0:
                raw_items = o_data.get("items", [])
                enriched_items = []
                
                product_ids = []
                for item in raw_items:
                    if not item: continue
                    pid = (
                        item.get("productId") or 
                        item.get("product", {}).get("id") or 
                        item.get("primaryComponent", {}).get("product", {}).get("id")
                    )
                    if pid: 
                        product_ids.append(pid)
                        if not item.get("productId"): item["productId"] = pid
                        
                    for mod in (item.get("modifiers") or []):
                        if not mod: continue
                        mpid = (
                            mod.get("productId") or 
                            mod.get("product", {}).get("id") or 
                            mod.get("primaryComponent", {}).get("product", {}).get("id")
                        )
                        if mpid: 
                            product_ids.append(mpid)
                            if not mod.get("productId"): mod["productId"] = mpid
                        
                # Достаем названия из локальной базы
                db_products = session.exec(select(Product).where(Product.iiko_id.in_(product_ids))).all()
                prod_map = {p.iiko_id: p.name for p in db_products}

                # Достаем старые названия из текущего состояния заказа
                old_names_map = {}
                if order.order_items_details:
                    for old_item in order.order_items_details:
                        old_pid = (
                            old_item.get("productId") or 
                            old_item.get("id") or 
                            old_item.get("product", {}).get("id") or 
                            old_item.get("primaryComponent", {}).get("product", {}).get("id")
                        )
                        old_name = old_item.get("name")
                        if old_pid and old_name and old_name != "Неизвестный товар":
                            old_names_map[old_pid] = old_name
                        
                        modifiers_list = old_item.get("modifiers") or []
                        for old_mod in modifiers_list:
                            old_mpid = (
                                old_mod.get("productId") or 
                                old_mod.get("id") or 
                                old_mod.get("product", {}).get("id") or 
                                old_mod.get("primaryComponent", {}).get("product", {}).get("id")
                            )
                            old_mname = old_mod.get("name")
                            if old_mpid and old_mname and old_mname != "Модификатор":
                                old_names_map[old_mpid] = old_mname
                
                for item in raw_items:
                    enriched_item = item.copy()
                    pid = item.get("productId")
                    
                    # Приоритет имени: product.name -> primaryComponent.product.name -> productName -> БД -> История -> Fallback
                    if not enriched_item.get("name") or enriched_item.get("name") == "Неизвестный товар":
                        enriched_item["name"] = (
                            enriched_item.get("product", {}).get("name") or 
                            enriched_item.get("primaryComponent", {}).get("product", {}).get("name") or 
                            enriched_item.get("productName") or 
                            prod_map.get(pid) or 
                            old_names_map.get(pid) or 
                            "Неизвестный товар"
                        )
                    
                    if not enriched_item.get("sum"):
                        enriched_item["sum"] = float(enriched_item.get("amount", 0)) * float(enriched_item.get("price", 0))
                        
                    enriched_mods = []
                    for mod in (item.get("modifiers") or []):
                        if not mod: continue
                        emod = mod.copy()
                        mpid = mod.get("productId")
                        
                        if not emod.get("name") or emod.get("name") == "Модификатор":
                            emod["name"] = (
                                emod.get("product", {}).get("name") or 
                                emod.get("primaryComponent", {}).get("product", {}).get("name") or 
                                prod_map.get(mpid) or 
                                old_names_map.get(mpid) or 
                                "Модификатор"
                            )
                        
                        if not emod.get("sum"):
                            emod["sum"] = float(emod.get("amount", 0)) * float(emod.get("price", 0))
                            
                        enriched_mods.append(emod)
                    
                    enriched_item["modifiers"] = enriched_mods
                    enriched_items.append(enriched_item)

                order.order_items_details = enriched_items
                flag_modified(order, "order_items_details")
            else:
                logger.info(f"Order {order_id_iiko}: No valid items in webhook payload, skipping items update to prevent data loss")

            order.base_amount = sum_total
            order.left_to_pay = left_to_pay
            order.payments_details = {"items": pm_list_detailed, "total_paid": total_paid}
            order.discounts_details = {"items": disc_list}
            order.updated_at = datetime.now(timezone.utc)
            
            flag_modified(order, "order_items_details")
            flag_modified(order, "discounts_details")
            flag_modified(order, "payments_details")
            session.add(order)
            session.commit()
            logger.info(f"Order {order_id_iiko} ({external_number}) synced. Status={mapped_status}, Paid={is_paid}")
            
        except Exception as e:
            logger.error(f"Error processing order: {e}", exc_info=True)
            session.rollback()

    async def sync_orders(self, session: Session, hours: int = 24):
        """
        Фоновая задача массовой синхронизации заказов.
        Используется для актуализации статусов (на случай пропуска вебхуков).
        """
        settings_db = session.exec(select(IikoSettings)).first()
        if not settings_db or not settings_db.organization_id:
            logger.warning("Iiko settings not found, sync aborted")
            return
            
        org_id = settings_db.organization_id
        
        # Определяем интервал на основе часового пояса из настроек
        from app.core.datetime_utils import get_tz_name, get_local_now
        tz_name = get_tz_name(session)
        now = get_local_now(tz_name)
        date_from = now - timedelta(hours=hours)
        date_to = now + timedelta(hours=1)
        
        logger.info(f"Mass sync starting: orders from {date_from} to {date_to}")
        
        all_ids = set()
        
        # 1. Из iiko Cloud
        try:
            try:
                # Пытаемся получить заказы за весь период
                cloud_orders = await iiko_service.get_orders_by_date(
                    date_from=date_from,
                    date_to=date_to,
                    organization_id=org_id,
                    api_login=settings_db.api_login,
                    log_error=False
                )
            except Exception as e:
                # Если iiko ругается на слишком большой объем данных (422 TOO_MANY_DATA_REQUESTED)
                # Или если мы ловим ошибку лимитов
                err_str = str(e).upper()
                if "422" in err_str or "TOO_MANY_DATA_REQUESTED" in err_str:
                    logger.warning("Iiko Cloud returned TOO_MANY_DATA_REQUESTED. Retrying in 4-hour chunks with delays...")
                    await asyncio.sleep(1.5) # Пауза перед ретраем
                    
                    cloud_orders = []
                    # Разбиваем на мелкие чанки по 4 часа
                    chunk_start = date_from
                    while chunk_start < date_to:
                        chunk_end = chunk_start + timedelta(hours=4)
                        if chunk_end > date_to:
                            chunk_end = date_to
                            
                        try:
                            batch = await iiko_service.get_orders_by_date(
                                date_from=chunk_start,
                                date_to=chunk_end,
                                organization_id=org_id,
                                api_login=settings_db.api_login,
                                log_error=False # Не логируем промежуточные ошибки
                            )
                            cloud_orders.extend(batch)
                            logger.info(f"Fetched {len(batch)} orders for period {chunk_start} - {chunk_end}")
                            # Пауза между чанками для избежания 429
                            await asyncio.sleep(1.0)
                        except Exception as chunk_err:
                            logger.error(f"Failed to fetch orders chunk ({chunk_start} - {chunk_end}): {chunk_err}")
                            # Если поймали 429 на чанке, подождем дольше
                            if "429" in str(chunk_err):
                                await asyncio.sleep(5.0)
                        
                        chunk_start = chunk_end
                else:
                    raise e

            for o in cloud_orders:
                if o.get("id"): all_ids.add(o["id"])
            logger.info(f"Found {len(cloud_orders)} orders in Cloud")
        except Exception as e:
            logger.error(f"Failed to fetch Cloud orders: {e}")
            
        # 2. Из iiko Resto (если настроен)
        if settings_db.resto_url and settings_db.resto_login:
            try:
                resto_ids = await iiko_service.get_resto_delivery_history(
                    date_from=date_from,
                    date_to=date_to,
                    resto_url=settings_db.resto_url,
                    resto_login=settings_db.resto_login,
                    resto_password=settings_db.resto_password,
                    log_error=False
                )
                for rid in resto_ids: all_ids.add(rid)
                logger.info(f"Found {len(resto_ids)} orders in Resto")
            except Exception as e:
                logger.error(f"Failed to fetch Resto orders: {e}")
                
        # 3. Дополнительно: Принудительно проверяем все активные заказы из нашей БД
        # Это критически важно, если iiko Cloud API по датам работает нестабильно или вебхуки пропущены
        try:
            # Включаем все статусы, которые не являются финальными (закрыт/отменен)
            active_statuses = [
                OrderStatus.new, 
                OrderStatus.unconfirmed, 
                OrderStatus.confirmed, 
                OrderStatus.preparing, 
                OrderStatus.cooking, 
                OrderStatus.ready, 
                OrderStatus.ready_for_pickup, 
                OrderStatus.delivering, 
                OrderStatus.delivered
            ]
            
            # Также добавим строковые представления на случай, если в БД закрались старые значения
            active_strings = [s.value for s in active_statuses] + [s.value.upper() for s in active_statuses]
            
            query = select(Order).where(Order.status.in_(active_strings))
            db_active_orders = session.exec(query).all()
            
            if db_active_orders:
                logger.info(f"Checking {len(db_active_orders)} active orders from local database: {[o.id for o in db_active_orders]}")
                for db_order in db_active_orders:
                    if db_order.iiko_order_id:
                        all_ids.add(str(db_order.iiko_order_id))
            else:
                logger.info("No active orders found in local database for extra sync check.")
            
        except Exception as e:
            logger.error(f"Failed to fetch active orders from DB for sync: {e}")
            import traceback
            logger.error(traceback.format_exc())

        logger.info(f"Syncing {len(all_ids)} unique orders...")
        
        success_count = 0
        for order_id in all_ids:
            try:
                # Добавляем небольшую задержку, чтобы не превысить лимиты API (429) 
                if success_count > 0 and success_count % 15 == 0:
                    await asyncio.sleep(0.5)

                # Используем sync_order_by_id для каждого заказа
                # Мы не хотим, чтобы ошибка в одном заказе прервала весь цикл
                res = await self.sync_order_by_id(session, order_id, org_id)
                if res: success_count += 1
            except Exception as e:
                logger.error(f"Failed to sync order {order_id}: {e}")
                
        logger.info(f"Mass sync finished. Total: {len(all_ids)}, Success: {success_count}")

    async def sync_order_by_id(self, session: Session, order_id: str, organization_id: str) -> bool:
        """Синхронизация конкретного заказа по ID (вызывается вебхуками)"""
        settings_db = session.exec(select(IikoSettings)).first()
        api_login = settings_db.api_login if settings_db else None
        try:
            order_data = await iiko_service.get_order_by_id(order_id, organization_id, api_login=api_login)
            if order_data:
                await self.process_iiko_order(session, order_data, organization_id)
                return True
        except Exception as e:
            logger.error(f"Failed to sync order {order_id}: {e}")
        return False

    async def sync_delivery_restrictions(self, session: Session) -> Dict[str, Any]:
        """Синхронизация зон и условий доставки из iiko Cloud"""
        settings_db = session.exec(select(IikoSettings)).first()
        if not settings_db or not settings_db.organization_id:
            return {"error": "Iiko not configured"}
            
        try:
            data = await iiko_service.get_delivery_restrictions(
                api_login=settings_db.api_login,
                organization_id=settings_db.organization_id
            )
            
            # Берем первый филиал как целевой (в текущей логике БД)
            branch = session.exec(select(Branch)).first()
            if not branch:
                return {"error": "No branch found in DB"}

            synced_count = 0
            # Структура ответа iiko: {"deliveryRestrictions": [{"organizationId": "...", "restrictions": [...], "deliveryRegionsMapUrl": "..."}]}
            
            # Собираем все полигоны из KML
            all_polygons = {}
            for org_data in data:
                map_url = org_data.get("deliveryRegionsMapUrl")
                if map_url:
                    logger.info(f"Найдена ссылка на карту в iiko: {map_url}. Загрузка полигонов...")
                    try:
                        kml_zones = await iiko_service.fetch_and_parse_kml(map_url)
                        for kz in kml_zones:
                            # Сохраняем полигон по имени зоны (в нижнем регистре для сопоставления)
                            name_key = kz["name"].lower().strip()
                            all_polygons[name_key] = kz["points"]
                            logger.info(f"Загружена геометрия для зоны из iiko-карты: {name_key}")
                    except Exception as e:
                        logger.error(f"Ошибка при загрузке полигонов по ссылке из iiko: {e}")

            for org_data in data:
                for res in org_data.get("restrictions", []):
                    zone_name = res.get("zone")
                    if not zone_name:
                        continue
                        
                    min_sum = float(res.get("minSum") or 0)
                    delivery_cost = float(res.get("deliveryPrice") or 0)
                    
                    # Используем zoneId из iiko если есть, иначе имя
                    iiko_zone_id = res.get("zoneId") or zone_name
                    
                    # Ищем ВСЕ зоны, привязанные к этому ID или с таким же именем
                    zones = session.exec(select(DeliveryZone).where(
                        (DeliveryZone.iiko_id == iiko_zone_id) | 
                        (DeliveryZone.name == zone_name)
                    )).all()
                    
                    if not zones:
                        logger.info(f"Создание новой зоны доставки: {zone_name}")
                        new_zone = DeliveryZone(name=zone_name, branch_id=branch.id, iiko_id=iiko_zone_id)
                        session.add(new_zone)
                        zones = [new_zone]
                    
                    for zone in zones:
                        # Принудительно обновляем iiko_id если он не был задан или изменился
                        if zone.iiko_id != iiko_zone_id:
                            zone.iiko_id = iiko_zone_id
                            
                        # Если зона была изменена руками - мы все равно обновляем её при синхронизации, 
                        # так как это явное действие пользователя "Синхронизировать"
                        # Но если хотим защитить - можно добавить проверку. 
                        # Пока убираем пропуск, чтобы сопоставление работало.
                        
                        zone.min_order_amount = min_sum
                        zone.delivery_cost = delivery_cost
                        zone.min_delivery_time = res.get("minDeliveryTime")
                        zone.max_delivery_time = res.get("maxDeliveryTime")
                        zone.free_delivery_sum = float(res.get("freeDeliverySum") or 0) if res.get("freeDeliverySum") is not None else None
                        zone.priority = int(res.get("priority") or 0)
                        zone.is_default = bool(res.get("isDefault"))
                        zone.updated_at = datetime.now(timezone.utc)
                        
                        # Добавляем координаты если нашли их в KML и у зоны ещё нет координат
                        if not zone.polygon_coordinates or zone.polygon_coordinates == '[]':
                            zone_key = zone_name.lower().strip()
                            if zone_key in all_polygons:
                                zone.polygon_coordinates = json.dumps(all_polygons[zone_key])
                                logger.info(f"Применена геометрия для зоны {zone.name} из KML-карты iiko")
                        
                        session.add(zone)
                        synced_count += 1


                    
                    # Добавляем координаты если нашли их в KML
                    zone_key = zone_name.lower().strip()
                    if zone_key in all_polygons:
                        import json
                        new_poly = json.dumps(all_polygons[zone_key])
                        # Обновляем только если координаты изменились или их нет
                        if zone.polygon_coordinates != new_poly:
                            logger.info(f"Обновление полигона для зоны: {zone.name}")
                            zone.polygon_coordinates = new_poly
                    elif not zone.polygon_coordinates or zone.polygon_coordinates == "[]":
                        # Если координат нет и в БД пусто, ставим пустой массив
                        zone.polygon_coordinates = "[]"
                    # Иначе (если в БД уже есть координаты, а в KML сейчас нет) - ОСТАВЛЯЕМ СТАРЫЕ
                    
                    # Дополнительная инфа
                    zone.additional_info = res
                    
                    session.add(zone)
                    synced_count += 1
            
            session.commit()
            logger.info(f"Синхронизация зон завершена: {synced_count} зон")
            return {"status": "success", "synced_zones": synced_count, "polygons_found": len(all_polygons)}
        except Exception as e:
            logger.error(f"Delivery zones sync failed: {e}")
            session.rollback()
            return {"error": str(e)}

    async def get_available_iiko_zones(self, session: Session) -> List[Dict[str, Any]]:
        """Получить список всех доступных зон из iiko Cloud (без сохранения)"""
        settings_db = session.exec(select(IikoSettings)).first()
        if not settings_db or not settings_db.organization_id:
            return []
            
        try:
            data = await iiko_service.get_delivery_restrictions(
                api_login=settings_db.api_login,
                organization_id=settings_db.organization_id
            )
            
            unique_zones = {}
            for org_data in data:
                for res in org_data.get("restrictions", []):
                    z_name = res.get("zone")
                    z_id = res.get("zoneId") or z_name
                    if z_name and z_id not in unique_zones:
                        unique_zones[z_id] = {
                            "iiko_id": z_id,
                            "name": z_name
                        }
            
            return list(unique_zones.values())
        except Exception as e:
            logger.error(f"Failed to fetch iiko zones list: {e}")
            return []

    async def sync_payment_types(self, session: Session) -> Dict[str, Any]:
        """Синхронизация типов оплаты из iiko Cloud"""
        from app.models.payment_type import PaymentType
        
        settings_db = session.exec(select(IikoSettings)).first()
        if not settings_db or not settings_db.organization_id:
            return {"error": "Iiko not configured"}
            
        try:
            print(f"DEBUG: Calling iiko_service.get_payment_types with login: {settings_db.api_login}", flush=True)
            payment_types = await iiko_service.get_payment_types(
                api_login=settings_db.api_login,
                organization_id=settings_db.organization_id
            )
            
            synced_count = 0
            logger.info(f"Начинаю обработку {len(payment_types)} типов оплаты из iiko")
            for pt in payment_types:
                pt_id = pt.get("id")
                if not pt_id: continue
                
                existing = session.exec(select(PaymentType).where(PaymentType.iiko_id == pt_id)).first()
                if existing:
                    existing.name = pt.get("name") or existing.name
                    existing.kind = pt.get("paymentTypeKind") or existing.kind
                    existing.updated_at = datetime.now(timezone.utc)
                    session.add(existing)
                else:
                    new_pt = PaymentType(
                        iiko_id=pt_id,
                        name=pt.get("name"),
                        kind=pt.get("paymentTypeKind"),
                        is_active=True # ОБЯЗАТЕЛЬНО! Иначе они пропадут при F5
                    )
                    session.add(new_pt)
                synced_count += 1
            
            logger.info(f"Синхронизация завершена. Всего: {synced_count}")
            session.commit()
            return {"status": "success", "synced_count": synced_count}
        except Exception as e:
            logger.error(f"Payment types sync failed: {e}")
            session.rollback()
            return {"error": str(e)}


    async def sync_stop_lists(self, session: Session = None):
        """Синхронизация стоп-листов"""
        # Логика стоп-листов
        pass

    async def sync_employees_full(self, session: Session, days: int = 7) -> None:
        """
        Полная синхронизация сотрудников и их смен через iiko RESTO (Office) API.
        """
        settings_db = session.exec(select(IikoSettings)).first()
        if not settings_db or not settings_db.resto_url:
            logger.error("Настройки iiko Resto (Office) не найдены. Синхронизация отменена.")
            return

        tz = self._get_tz(session)
        now_local = datetime.now(tz)
        date_from = now_local - timedelta(days=days)

        # --- Шаг 1: Синхронизация профилей сотрудников ---
        # Параметры подключения берём из БД, а не из ENV
        r_url = settings_db.resto_url
        r_login = settings_db.resto_login
        r_password = settings_db.resto_password
        try:
            logger.info("Запрос списка сотрудников из iiko Resto...")
            iiko_employees = await iiko_service.get_resto_employees(
                resto_url=r_url, resto_login=r_login, resto_password=r_password
            )
            
            for emp in iiko_employees:
                emp_iiko_id = emp.get("id")
                if not emp_iiko_id: continue
                
                name = emp.get("name") or f"{emp.get('firstName', '')} {emp.get('lastName', '')}".strip()
                role = emp.get("role")
                rate = emp.get("salary")
                
                # Документы и доп. инфо
                doc_info = {
                    "inn": emp.get("inn"),
                    "snils": emp.get("snils"),
                    "code": emp.get("code"),
                    "cardNumber": emp.get("cardNumber"),
                    "birthday": emp.get("birthday")
                }
                
                existing = session.exec(
                    select(Employee).where(Employee.iiko_id == emp_iiko_id)
                ).first()
                
                def _flag_courier(r, n=""):
                    r_l = (r or "").lower()
                    n_l = (n or "").lower()
                    return ("курьер" in r_l or "courier" in r_l or r_l in ["cur", "cour"]
                            or "курьер" in n_l or "courier" in n_l)
                def _flag_admin(r, n=""):
                    r_l = (r or "").lower()
                    return any(k in r_l for k in ["администратор", "оператор", "manager", "старший", "adm", "admin"])

                if existing:
                    existing.name = name
                    existing.role = role or existing.role
                    existing.phone = emp.get("phone") or existing.phone
                    existing.email = emp.get("email") or existing.email
                    existing.address = emp.get("address") or existing.address
                    existing.rate = rate if rate is not None else existing.rate
                    existing.document_info = doc_info
                    existing.status = "Deleted" if emp.get("deleted") else "Active"
                    existing.is_courier = _flag_courier(existing.role, existing.name)
                    existing.is_admin = _flag_admin(existing.role)
                    existing.updated_at = datetime.now(timezone.utc)
                    session.add(existing)
                else:
                    new_emp = Employee(
                        iiko_id=emp_iiko_id,
                        name=name,
                        role=role,
                        phone=emp.get("phone"),
                        email=emp.get("email"),
                        address=emp.get("address"),
                        rate=rate or 0.0,
                        document_info=doc_info,
                        status="Deleted" if emp.get("deleted") else "Active",
                        is_courier=_flag_courier(role, name),
                        is_admin=_flag_admin(role),
                        created_at=datetime.now(timezone.utc),
                        updated_at=datetime.now(timezone.utc)
                    )
                    session.add(new_emp)
            
            session.commit()
            logger.info(f"✅ Синхронизировано {len(iiko_employees)} профилей сотрудников из iiko Resto")
        except Exception as e:
            logger.error(f"Ошибка синхронизации профилей: {e}")
            session.rollback()

        # --- Шаг 1.5: Дополнение данными из iiko Cloud (преимущественно для курьеров) ---
        try:
            logger.info("Запрос дополнительных данных из iiko Cloud...")
            cloud_employees = await iiko_service.get_employees(api_login=settings_db.api_login, organization_id=settings_db.organization_id)
            updated_cloud_c = 0
            for c_emp in cloud_employees:
                emp_iiko_id = c_emp.get("id")
                if not emp_iiko_id: continue
                
                existing = session.exec(select(Employee).where(Employee.iiko_id == emp_iiko_id)).first()
                # Если сотрудника нет из Resto, но он есть в Cloud (например, внешний курьер)
                if not existing:
                    role = ""
                    if c_emp.get("isCourier"): role = "Курьер (Cloud)"
                    
                    new_emp = Employee(
                        iiko_id=emp_iiko_id,
                        name=c_emp.get("name", "Unknown"),
                        role=role,
                        phone=c_emp.get("phone"),
                        status="Active",
                        is_courier=c_emp.get("isCourier", False),
                        created_at=datetime.now(timezone.utc),
                        updated_at=datetime.now(timezone.utc)
                    )
                    session.add(new_emp)
                    updated_cloud_c += 1
                else:
                    # Дополняем данными, если их нет
                    if c_emp.get("isCourier") and not existing.is_courier:
                        existing.is_courier = True
                        session.add(existing)
                        updated_cloud_c += 1
            session.commit()
            logger.info(f"✅ Дополнено {updated_cloud_c} профилей из iiko Cloud")
        except Exception as e:
            logger.error(f"Ошибка дополнения данных из Cloud: {e}")
            session.rollback()

        # --- Шаг 2: Синхронизация исторических смен через Attendance API ---
        try:
            logger.info(f"Запрос явок (смен) через Attendance API ({date_from.date()} - {now_local.date()})...")
            attendance_records = await iiko_service.get_resto_attendance(
                resto_url=r_url, resto_login=r_login, resto_password=r_password,
                date_from=date_from, date_to=now_local,
                log_error=False
            )

            def _parse_to_utc(s):
                if not s: return None
                try:
                    # формат ISO 8601 с таймзоной (например 2026-04-11T10:17:00+05:00)
                    return datetime.fromisoformat(str(s)).astimezone(timezone.utc)
                except Exception:
                    return None

            created_c, updated_c = 0, 0
            for row in attendance_records:
                emp_iiko_id = row.get("employeeId")
                if not emp_iiko_id:
                    continue

                employee = session.exec(select(Employee).where(Employee.iiko_id == emp_iiko_id)).first()
                if not employee:
                    # logger.debug(f"Attendance: сотрудник с ID '{emp_iiko_id}' не найден в БД")
                    continue

                date_open = _parse_to_utc(row.get("dateOpen"))
                date_close = _parse_to_utc(row.get("dateClose"))
                if not date_open:
                    continue

                if not date_close:
                    now_utc = datetime.now(timezone.utc)
                    work_hours = (now_utc - date_open).total_seconds() / 3600.0
                else:
                    work_hours = (date_close - date_open).total_seconds() / 3600.0

                # Ограничиваем аномально длинные смены (макс 24 часа)
                work_hours = min(work_hours, 24.0)

                # Уникальный ключ
                shift_iiko_id = row.get("id")
                if not shift_iiko_id:
                     shift_iiko_id = f"att_{employee.id}_{date_open.strftime('%Y%m%d%H%M')}"

                # Поиск выручки при закрытии (из загруженных отчетов OLAP)
                revenue_at_close = 0.0
                if date_close:
                    biz_date_str = date_open.astimezone(tz).strftime("%Y-%m-%d")
                    # Берем выручку за бизнес-день открытия смены
                    rev_record = session.exec(
                        select(OlapRevenueRecord)
                        .where(OlapRevenueRecord.business_date == biz_date_str)
                        .order_by(OlapRevenueRecord.updated_at.desc())
                    ).first()
                    if rev_record:
                        revenue_at_close = rev_record.revenue

                existing_shift = session.exec(
                    select(Shift).where(Shift.iiko_id == shift_iiko_id)
                ).first()

                if existing_shift:
                    existing_shift.date_close = date_close
                    existing_shift.status = "CLOSED" if date_close else "OPEN"
                    existing_shift.work_hours = round(work_hours, 2)
                    # Обновляем выручку только если она еще не была установлена
                    if date_close and (not existing_shift.revenue_at_close or existing_shift.revenue_at_close == 0):
                        existing_shift.revenue_at_close = revenue_at_close
                    existing_shift.updated_at = datetime.now(timezone.utc)
                    session.add(existing_shift)
                    updated_c += 1
                else:
                    new_shift = Shift(
                        iiko_id=shift_iiko_id,
                        employee_id=employee.id,
                        date_open=date_open,
                        date_close=date_close,
                        status="CLOSED" if date_close else "OPEN",
                        work_hours=round(work_hours, 2),
                        cancelled_orders_count=0,
                        revenue_at_close=revenue_at_close,
                        created_at=datetime.now(timezone.utc),
                        updated_at=datetime.now(timezone.utc)
                    )
                    session.add(new_shift)
                    created_c += 1

            session.commit()
            logger.info(f"✅ Attendance смены: создано {created_c}, обновлено {updated_c} из {len(attendance_records)} строк")
        except Exception as e:
            logger.error(f"Ошибка синхронизации Attendance смен: {e}", exc_info=True)
            session.rollback()

        # --- Шаг 3 (Удален): Синхронизация через personalSessions заменена на Attendance ---
        # Личные смены теперь полностью обрабатываются в Шаге 2 через Attendance API, 
        # который возвращает и открытые, и закрытые смены без ошибок 404.
        pass

    async def get_employee_stats(self, session: Session, employee_id: int, mode: str = "calendar") -> Dict[str, Any]:
        """
        Получение статистики сотрудника за период.
        mode: 'calendar' (текущая неделя) или 'sliding' (последние 7 дней)
        """
        tz = self._get_tz(session)
        now_local = datetime.now(tz)
        
        if mode == "calendar":
            # С понедельника текущей недели
            start_date = (now_local - timedelta(days=now_local.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
            end_date = now_local
        else:
            # Последние 7 дней
            start_date = (now_local - timedelta(days=7)).replace(hour=0, minute=0, second=0, microsecond=0)
            end_date = now_local
            
        # Загружаем смены из БД
        shifts = session.exec(
            select(Shift)
            .where(Shift.employee_id == employee_id)
            .where(Shift.date_open >= start_date.astimezone(timezone.utc))
            .order_by(Shift.date_open.desc())
        ).all()
        
        total_hours = sum(s.work_hours for s in shifts if s.work_hours)
        total_revenue = sum(float(s.revenue_at_close or 0) for s in shifts)
        
        # Группировка по дням
        daily_stats = {}
        for s in shifts:
            # Приводим время открытия к локальному для группировки по дате
            s_open_local = s.date_open.astimezone(tz)
            day_key = s_open_local.date().isoformat()
            
            if day_key not in daily_stats:
                daily_stats[day_key] = {
                    "date": day_key,
                    "total_hours": 0.0,
                    "shifts_count": 0,
                    "revenue": 0.0,
                    "shifts": []
                }
            
            daily_stats[day_key]["total_hours"] += float(s.work_hours or 0)
            daily_stats[day_key]["shifts_count"] += 1
            daily_stats[day_key]["revenue"] += float(s.revenue_at_close or 0)
            
            # Формируем объект смены для фронтенда
            shift_info = {
                "id": s.id,
                "open": s_open_local.isoformat(),
                "close": s.date_close.astimezone(tz).isoformat() if s.date_close else None,
                "status": s.status,
                "hours": round(s.work_hours, 2) if s.work_hours else 0,
                "revenue": float(s.revenue_at_close or 0)
            }
            daily_stats[day_key]["shifts"].append(shift_info)
            
        return {
            "total_hours_period": round(total_hours, 2),
            "total_shifts": len(shifts),
            "total_revenue": round(total_revenue, 2),
            "daily_stats": sorted(daily_stats.values(), key=lambda x: x["date"], reverse=True)
        }

    async def sync_courier_deliveries(self, session: Session, days: int = 14) -> None:
        """
        Синхронизация детальных доставок курьеров из iiko Resto OLAP.
        Заполняет таблицу courier_orders: зоны, суммы, временные метки, задержки.
        """
        settings_db = session.exec(select(IikoSettings)).first()
        if not settings_db or not settings_db.resto_url:
            logger.warning("Resto не настроен — синхронизация доставок пропущена")
            return

        tz = self._get_tz(session)
        now_local = datetime.now(tz)
        date_from = now_local - timedelta(days=days)

        logger.info(f"Синхронизация доставок курьеров из Resto OLAP ({date_from.date()} — {now_local.date()})...")

        try:
            deliveries = await iiko_service.get_resto_detailed_deliveries(
                date_from=date_from,
                date_to=now_local,
                organization_id=settings_db.organization_id or "",
                resto_url=settings_db.resto_url,
                resto_login=settings_db.resto_login,
                resto_password=settings_db.resto_password
            )
            print(f"DEBUG: Fetched {len(deliveries)} deliveries from OLAP")
        except Exception as e:
            logger.error(f"Ошибка получения доставок из Resto OLAP: {e}")
            return

        # Кэш курьеров по имени (нижний регистр)
        all_employees = session.exec(select(Employee)).all()
        courier_by_name: Dict[str, Employee] = {}
        for emp in all_employees:
            # Учитываем флаг is_courier и различные написания ролей
            is_c = emp.is_courier or any(k in (emp.role or "").lower() for k in ["курьер", "courier", "cur"])
            if is_c:
                courier_by_name[emp.name.lower().strip()] = emp

        def _parse_dt(s):
            if not s: return None
            try:
                s_c = str(s).replace("T", " ").split(".")[0]
                return datetime.fromisoformat(s_c).replace(tzinfo=tz).astimezone(timezone.utc)
            except Exception:
                return None

        created_count, updated_count = 0, 0
        for d in deliveries:
            order_num = str(d.get("id") or "").strip()
            if not order_num:
                continue

            courier_info = d.get("courierInfo") or {}
            courier_name_raw = (courier_info.get("courier") or {}).get("name") or ""
            courier_name_key = courier_name_raw.lower().strip()

            courier_emp = courier_by_name.get(courier_name_key)
            if not courier_emp:
                # Пробуем по словам
                def _get_meaningful_words(name):
                    words = name.lower().split()
                    return {w for w in words if len(w) > 2 and w not in ["курьер", "courier", "cur"]}
                
                target_words = _get_meaningful_words(courier_name_raw)
                for key, emp in courier_by_name.items():
                    emp_words = _get_meaningful_words(emp.name)
                    if target_words and emp_words and (target_words & emp_words):
                        courier_emp = emp
                        break

            # ФОЛЛБЭК: Если в OLAP WaiterName не курьер, ищем в нашей таблице orders (из вебхуков)
            if not courier_emp:
                from app.models.order import Order
                db_order = session.exec(
                    select(Order).where(Order.external_number == order_num)
                ).first()
                if db_order and db_order.courier_name and db_order.courier_name != "Не назначен":
                    c_name_raw = db_order.courier_name
                    c_name_key = c_name_raw.lower().strip()
                    courier_emp = courier_by_name.get(c_name_key)
                    if not courier_emp:
                        target_words = _get_meaningful_words(c_name_raw)
                        for key, emp in courier_by_name.items():
                            emp_words = _get_meaningful_words(emp.name)
                            if target_words and emp_words and (target_words & emp_words):
                                courier_emp = emp
                                break

            if not courier_emp:
                logger.debug(f"Курьер '{courier_name_raw}' не найден в БД — пропускаем заказ {order_num}")
                continue

            # Временные метки
            cooking_done = _parse_dt(d.get("whenCookingCompleted"))
            expected_dt = _parse_dt(d.get("expectedDeliveryTime"))
            actual_dt = _parse_dt(d.get("whenDelivered"))

            # Задержка
            delay_min = None
            is_late = False
            if expected_dt and actual_dt:
                diff = (actual_dt - expected_dt).total_seconds() / 60
                delay_min = int(diff)
                is_late = diff > 0

            # Адрес из OLAP
            addr_parts = d.get("address") or {}
            address_str = " ".join(filter(None, [
                addr_parts.get("street"),
                addr_parts.get("house"),
                f"кв. {addr_parts['flat']}" if addr_parts.get("flat") else None
            ]))

            # iiko_id = order_num (уникальность по номеру заказа + дата)
            iiko_uid = f"olap_{order_num}_{(actual_dt or cooking_done or datetime.now(timezone.utc)).strftime('%Y%m%d')}"

            existing = session.exec(
                select(CourierOrder).where(CourierOrder.iiko_id == iiko_uid)
            ).first()

            if existing:
                existing.delivery_zone = d.get("deliveryZone") or existing.delivery_zone
                existing.amount = float(d.get("sum") or 0) or existing.amount
                existing.cooking_completed_at = cooking_done or existing.cooking_completed_at
                existing.expected_delivery_time = expected_dt or existing.expected_delivery_time
                existing.actual_delivery_time = actual_dt or existing.actual_delivery_time
                existing.delay_minutes = delay_min
                existing.is_late = is_late
                existing.address = address_str or existing.address
                existing.close_time = actual_dt
                existing.updated_at = datetime.now(timezone.utc)
                session.add(existing)
                updated_count += 1
            else:
                new_order = CourierOrder(
                    iiko_id=iiko_uid,
                    order_num=order_num,
                    employee_id=courier_emp.id,
                    address=address_str,
                    delivery_zone=d.get("deliveryZone"),
                    amount=float(d.get("sum") or 0),
                    created_at_iiko=cooking_done,
                    cooking_completed_at=cooking_done,
                    expected_delivery_time=expected_dt,
                    actual_delivery_time=actual_dt,
                    close_time=actual_dt,
                    delay_minutes=delay_min,
                    is_late=is_late,
                    created_at=datetime.now(timezone.utc),
                    updated_at=datetime.now(timezone.utc)
                )
                session.add(new_order)
                created_count += 1

        try:
            session.commit()
            logger.info(f"✅ Синхронизация доставок: создано {created_count}, обновлено {updated_count}")
        except Exception as e:
            logger.error(f"Ошибка commit синхронизации доставок: {e}")
            session.rollback()


    async def sync_zones_from_external_map(self, session: Session, url: Optional[str] = None) -> Dict[str, Any]:
        """
        Синхронизация геометрии зон доставки по внешней ссылке (Google Maps KML)
        """
        settings = session.exec(select(IikoSettings)).first()
        
        # Если URL передан явно, сохраняем его в настройки
        if url:
            if settings:
                settings.delivery_zones_map_url = url
                session.add(settings)
                session.commit()
            map_url = url
        else:
            map_url = settings.delivery_zones_map_url if settings else None

        if not map_url:
            return {"success": False, "error": "Ссылка на карту не задана в настройках"}
        
        logger.info(f"Начало импорта геометрии зон из: {map_url}")
        
        # 1. Загружаем и парсим KML
        try:
            from .iiko_service import iiko_service
            kml_zones = await iiko_service.fetch_and_parse_kml(settings.delivery_zones_map_url)
            if not kml_zones:
                return {"success": False, "error": "Не удалось получить зоны из указанной ссылки. Проверьте доступ к карте."}
        except Exception as e:
            return {"success": False, "error": f"Ошибка при загрузке карты: {str(e)}"}
            
        # 2. Сопоставляем и обновляем
        updated_count = 0
        import json
        from app.models.company import DeliveryZone
        
        all_zones = session.exec(select(DeliveryZone)).all()
        
        for kz in kml_zones:
            name = kz["name"].strip()
            points = kz["points"]
            
            # Ищем зону в БД по имени (регистронезависимо)
            matched_zone = next((z for z in all_zones if z.name.lower() == name.lower()), None)
            
            if matched_zone:
                # Сохраняем как JSON строку (согласно модели)
                matched_zone.polygon_coordinates = json.dumps(points)
                matched_zone.updated_at = datetime.now(timezone.utc)
                session.add(matched_zone)
                updated_count += 1
                logger.info(f"Обновлена геометрия для зоны: {name}")
            else:
                logger.warning(f"Зона из KML '{name}' не найдена в базе данных iiko")
                
        try:
            session.commit()
            # Очищаем кэш после обновления зон (если используется Redis или локальный кэш)
            try:
                from app.core.redis import redis_client
                await redis_client.delete("delivery_zones_all")
                logger.info("Кэш зон доставки очищен")
            except Exception:
                pass

            return {
                "success": True, 
                "updated_count": updated_count, 
                "total_from_map": len(kml_zones),
                "message": f"Обновлено зон: {updated_count} из {len(kml_zones)}"
            }
        except Exception as e:
            session.rollback()
            logger.error(f"Ошибка сохранения геометрии зон: {e}")
            return {"success": False, "error": f"Ошибка сохранения в БД: {str(e)}"}


    async def sync_zones_from_kml_file(self, session: Session, kml_content: str) -> Dict[str, Any]:
        """
        Синхронизация геометрии зон доставки из загруженного KML файла
        """
        logger.info("Начало импорта геометрии зон из загруженного файла")
        
        # 1. Парсим KML
        try:
            from .iiko_service import iiko_service
            kml_zones = iiko_service.parse_kml_content(kml_content)
            if not kml_zones:
                return {"success": False, "error": "В файле не найдено полигонов зон доставки."}
        except Exception as e:
            return {"success": False, "error": f"Ошибка при парсинге файла: {str(e)}"}
            
        # 2. Сопоставляем и обновляем
        updated_count = 0
        import json
        from app.models.company import DeliveryZone
        
        all_zones = session.exec(select(DeliveryZone)).all()
        
        for kz in kml_zones:
            name = kz["name"].strip()
            points = kz["points"]
            description = kz.get("description", "")
            extended_data = kz.get("extended_data", {})
            
            # Ищем зону в БД по имени (регистронезависимо)
            matched_zone = session.exec(select(DeliveryZone).where(func.lower(DeliveryZone.name) == name.lower())).first()
            
            if matched_zone:
                matched_zone.polygon_coordinates = json.dumps(points)
                matched_zone.description = description
                matched_zone.additional_info = extended_data
                matched_zone.is_manual_override = True  # Приоритет пользователя
                matched_zone.updated_at = datetime.now(timezone.utc)
                session.add(matched_zone)
                updated_count += 1
                logger.info(f"Обновлена геометрия и метаданные для зоны (из KML): {name}")
            else:
                # Создаем новую зону если её нет
                logger.info(f"Создание новой приоритетной зоны из KML файла: {name}")
                from app.models.company import Branch
                branch = session.exec(select(Branch)).first()
                if branch:
                    new_zone = DeliveryZone(
                        name=name,
                        branch_id=branch.id,
                        polygon_coordinates=json.dumps(points),
                        description=description,
                        additional_info=extended_data,
                        is_manual_override=True,  # Приоритет пользователя
                        is_active=True
                    )
                    session.add(new_zone)
                    updated_count += 1
                else:
                    logger.warning(f"Не удалось создать зону {name}: филиал не найден")
                
        try:
            session.commit()
            # Очищаем кэш
            try:
                from app.core.redis import redis_client
                await redis_client.delete("delivery_zones_all")
            except Exception:
                pass

            return {
                "success": True, 
                "updated_count": updated_count, 
                "total_from_file": len(kml_zones),
                "message": f"Обновлено зон из файла: {updated_count} из {len(kml_zones)}"
            }
        except Exception as e:
            session.rollback()
            logger.error(f"Ошибка сохранения геометрии зон из файла: {e}")
            return {"success": False, "error": f"Ошибка сохранения в БД: {str(e)}"}


iiko_sync_service = IikoSyncService()
