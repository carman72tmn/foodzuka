"""
API эндпоинты для управления Клиентами
"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlmodel import Session, select
from app.core.database import get_session
from app.models.customer import Customer
from app.schemas import CustomerCreate, CustomerUpdate, CustomerResponse

router = APIRouter(prefix="/customers", tags=["Customers"])

@router.get("/", response_model=List[CustomerResponse])
async def get_customers(
    skip: int = 0,
    limit: int = 100,
    search: Optional[str] = None,
    session: Session = Depends(get_session)
):
    """Список клиентов с возможностью поиска по телефону или имени"""
    query = select(Customer).order_by(Customer.created_at.desc()).offset(skip).limit(limit)
    
    if search:
        query = query.where(
            Customer.phone.contains(search) | Customer.name.contains(search)
        )
        
    customers = session.exec(query).all()
    return customers

@router.get("/{customer_id}", response_model=CustomerResponse)
async def get_customer(customer_id: int, session: Session = Depends(get_session)):
    """Детали одного клиента"""
    customer = session.get(Customer, customer_id)
    if not customer:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Customer not found")
    return customer

@router.post("/", response_model=CustomerResponse, status_code=status.HTTP_201_CREATED)
async def create_customer(
    customer_data: CustomerCreate,
    session: Session = Depends(get_session)
):
    """Создать профиль клиента"""
    existing = session.exec(select(Customer).where(Customer.phone == customer_data.phone)).first()
    if existing:
        raise HTTPException(status_code=400, detail="Customer with this phone already exists")
        
    customer = Customer(**customer_data.model_dump())
    session.add(customer)
    session.commit()
    session.refresh(customer)
    return customer

@router.patch("/{customer_id}", response_model=CustomerResponse)
async def update_customer(
    customer_id: int,
    customer_data: CustomerUpdate,
    session: Session = Depends(get_session)
):
    """Обновление профиля клиента"""
    customer = session.get(Customer, customer_id)
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")

    update_data = customer_data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(customer, key, value)

    session.add(customer)
    session.commit()
    session.refresh(customer)
    return customer

@router.post("/{customer_id}/sync", response_model=CustomerResponse)
async def sync_customer(customer_id: int, session: Session = Depends(get_session)):
    """Синхронизация данных клиента с iiko Loyalty Server"""
    from app.services.iiko_service import iiko_service
    from datetime import date, timezone, datetime
    from decimal import Decimal
    
    customer = session.get(Customer, customer_id)
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
        
    try:
        # Получаем данные из iiko
        iiko_data = await iiko_service.get_customer_info(customer.phone)
        
        if iiko_data.get("id"): # Если клиент найден (есть ID)
            # Обновляем локальные данные
            if iiko_data.get("name"):
                customer.name = iiko_data["name"]
            if iiko_data.get("email"):
                customer.email = iiko_data["email"]
            if iiko_data.get("birthday"):
                try:
                    # iiko обычно присылает дату в формате "2024-03-27 00:00:00.000"
                    bday_str = iiko_data["birthday"].split(" ")[0]
                    customer.birthday = date.fromisoformat(bday_str)
                except Exception:
                    pass
            
            # Обновляем бонусы
            if "walletBalances" in iiko_data:
                total_bonuses = sum(float(b.get("balance", 0)) for b in iiko_data["walletBalances"])
                customer.bonus_points = Decimal(str(total_bonuses))
            
            customer.iiko_customer_id = iiko_data.get("id")
            customer.updated_at = datetime.now(timezone.utc)
            
            session.add(customer)
            session.commit()
            session.refresh(customer)
            
        return customer
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Sync failed: {str(e)}")
